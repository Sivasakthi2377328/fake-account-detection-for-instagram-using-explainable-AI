import pickle

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

train_data = pd.read_csv('train.csv')
test_data = pd.read_csv('test.csv')
x_train = train_data.drop(columns=['fake'])
x_test = test_data.drop(columns=['fake'])
y_train = train_data['fake']
y_test = test_data['fake']

scaler = StandardScaler()
x_train = scaler.fit_transform(x_train)
x_test = scaler.transform(x_test)

# Logistic Regression
# print("Logistic Regression")
# model = LogisticRegression()
# model.fit(x_train, y_train)
#
# # Predicting and evaluating the model
# predictions = model.predict(x_test)
# temp = []
# for i in predictions:
#     temp.append(i)
# print('Real Count = ', temp.count(0))
# print('Fake Count = ', temp.count(1))
# Random Forest Classifier
# print("Random Forest Classifier")
#
# model = RandomForestClassifier()  # max_depth is a hyperparameter
# model.fit(x_train, y_train)

# Predicting and evaluating the model
# predictions = model.predict(x_test)
# temp = []
# for i in predictions:
#     temp.append(i)
# print('Real Count = ', temp.count(0))
# print('Fake Count = ', temp.count(1))
#
# # Support Vector Machine
# print("Support Vector Machine")
#
# model = DecisionTreeClassifier()
# model.fit(x_train, y_train)
#
# # Predicting and evaluating the model
# predictions = model.predict(x_test)
# temp = []
# for i in predictions:
#     temp.append(i)
# print('Real Count = ', temp.count(0))
# print('Fake Count = ', temp.count(1))

# Voting Classifier
print("Voting Classifier")

model1 = LogisticRegression()
model2 = RandomForestClassifier()
model3 = make_pipeline(StandardScaler(), SVC(probability=True))

# Creating the voting classifier
model = VotingClassifier(
    estimators=[('lr', model1), ('rf', model2), ('svm', model3)],
    voting='hard',
    verbose=1
)

model.fit(x_train, y_train)
# predictions = model.predict(scaler.transform([[
#     0, 0.44, 1, 0.44, 1, 112, 0, 0, 4, 415, 1445
# ]]))
# print(predictions)
# temp = []
# for i in predictions:
#     temp.append(i)
# print('Real Count = ', temp.count(0))
# print('Fake Count = ', temp.count(1))
# with open('model.pkl', 'wb') as file:
#     pickle.dump(model, file)
# print("File Writed")

# with open('model.pkl', 'rb') as file:
#     loaded_model = pickle.load(file)
#
# # Now you can use the loaded model to make predictions
# predictions = loaded_model.predict([[
#     0, 0.21, 0, 1, 0.21, 20, 0, 1, 900, 2, 1
# ]])
# print("Predictions", predictions)
# predictions = voting_clf.predict(x_test)
# print("Correct Predictions : ", np.sum(predictions == y_test))
# print("Confusion Matrix:\n", confusion_matrix(y_test, predictions))
# print("Classification Report:\n", classification_report(y_test, predictions))
#
# print(f'Accuracy = {accuracy_score(y_test, predictions)}')
#
# # Compute the confusion matrix
# cm = confusion_matrix(y_test, predictions)
#
# # Plot the confusion matrix
# plt.figure(figsize=(8, 6))
# sns.heatmap(cm, annot=True, fmt="d", linewidths=.5, cmap='Blues')
# plt.title('Confusion Matrix')
# plt.xlabel('Predicted Labels')
# plt.ylabel('True Labels')
# plt.show()
#
# # Stacking
# print("Stacking Classifier")
# # Define base models
# base_models = [
#     ('lr', LogisticRegression(random_state=1, max_iter=1000)),
#     ('rf', RandomForestClassifier(n_estimators=100, random_state=42)),
#     ('svm', make_pipeline(StandardScaler(), SVC(probability=True, shrinking=False, verbose=1))),
# ]
#
# # Define a meta-model
# meta_model = LogisticRegression()
#
# # Create the stacking classifier
# stack_model = StackingClassifier(estimators=base_models, final_estimator=meta_model)
#
# stack_model.fit(x_train, y_train)
#
# predictions = stack_model.predict(x_test)
# print("Correct Predictions : ", np.sum(predictions == y_test))
# print("Confusion Matrix:\n", confusion_matrix(y_test, predictions))
# print("Classification Report:\n", classification_report(y_test, predictions))
#
# print(f'Accuracy = {accuracy_score(y_test, predictions)}')
#
# # Compute the confusion matrix
# cm = confusion_matrix(y_test, predictions)
#
# # Plot the confusion matrix
# plt.figure(figsize=(8, 6))
# sns.heatmap(cm, annot=True, fmt="d", linewidths=.5, cmap='Blues')
# plt.title('Confusion Matrix')
# plt.xlabel('Predicted Labels')
# plt.ylabel('True Labels')
# plt.show()
