from nltk import accuracy
from sklearn.linear_model import LogisticRegression
import tensorflow as tf
import numpy as np
from sklearn.metrics import accuracy_score, classification_report
from sklearn.svm import SVC
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout


def fake_account_detection():
    data = pd.read_csv("train.csv")
    data1 = pd.read_csv("test.csv")

    x_train = data.drop(columns=['fake'])
    y_train = data['fake']
    x_test = data1.drop(columns=['fake'])
    y_test = data1['fake']
    scaler = StandardScaler()
    x_train = scaler.fit_transform(x_train)
    x_test = scaler.transform(x_test)
    y_train = tf.keras.utils.to_categorical(y_train, num_classes=2)
    y_test = tf.keras.utils.to_categorical(y_test, num_classes=2)

    model = Sequential()
    model.add(Dense(50, input_dim=11, activation='relu'))
    model.add(Dense(150, activation='relu'))
    model.add(Dropout(0.3))
    model.add(Dense(150, activation='relu'))
    model.add(Dropout(0.3))
    model.add(Dense(25, activation='relu'))
    model.add(Dropout(0.3))
    model.add(Dense(2, activation='softmax'))

    model.summary()

    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    model.fit(x_train, y_train, epochs=50, verbose=1, validation_split=0.2)
    predict = model.predict(scaler.transform(np.array([[1, 0.27, 0, 0, 0, 53, 0, 0, 32, 1000, 955]])))
    # predicted_value = []
    # test = []
    # for i in predict:
    #     predicted_value.append(np.argmax(i))
    #
    # for i in y_test:
    #     test.append(np.argmax(i))
    # print(classification_report(y_test, predict))
    print(f'Accuracy = {accuracy_score(y_test, predict)}')

    # x_train, x_test, y_train, y_test = train_test_split(x_train, y_train, test_size=0.2, random_state=42)
    # logistic_regression(x_test, x_train, y_train, y_test)
    # random_forest(x_test, x_train, y_train, y_test)
    # support_vector(x_test, x_train, y_train, y_test)


def logistic_regression(x_test, x_train, y_train, y_test):
    # Logistic Regression
    clf = LogisticRegression(random_state=1, max_iter=1000)
    clf.fit(x_train, y_train)
    # print(accuracy(y_test, clf.predict(x_test)) * 100)


def random_forest(x_test, x_train, y_train, y_test):
    # Random Forest Classifier
    rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_classifier.fit(x_train, y_train)
    # print(accuracy(y_test, rf_classifier.predict(x_test)) * 100)


def support_vector(x_test, x_train, y_train, y_test):
    # Support Vector Machine
    scaler = StandardScaler()
    x_train_scaled = scaler.fit_transform(x_train)
    classifier = SVC(kernel='linear')
    classifier.fit(x_train_scaled, y_train)
    # print(accuracy(y_test, classifier.predict(scaler.transform(x_test))) * 100)


fake_account_detection()
