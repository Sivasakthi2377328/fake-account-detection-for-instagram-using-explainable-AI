from flask import Flask, request, render_template

import insta

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/get-user-data', methods=['GET'])
def get_user_data():  # put application's code here
    username = request.args.get('username')
    return insta.get_user_data(username=username)


@app.route('/get-account-type', methods=['GET'])
def get_account_type():
    username = request.args.get('username')
    return insta.get_data(username=username)


if __name__ == '__main__':
    app.run()
