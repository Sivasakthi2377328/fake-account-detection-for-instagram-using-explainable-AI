#!/usr/bin/env python
# coding: utf-8

# In[1]:


# conda install -c conda-forge shap


# In[11]:


import sklearn
import pandas as pd
import shap
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

data = pd.read_csv("train.csv")

x = data.drop(columns=['fake'])
y = data['fake']
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)
model = RandomForestClassifier(n_estimators=100)
model.fit(X_train, y_train)
explainer = shap.Explainer(model)
print(X_test)
shap_values = explainer.shap_values(X_test)
shap.summary_plot(shap_values, X_test)
X100 = shap.utils.sample(X_train, 100)

# In[12]:


shap.partial_dependence_plot(
    "profilepic",
    model.predict,
    X100,
    ice=False,
    model_expected_value=True,
    feature_expected_value=True,
)

# In[10]:


shap.partial_dependence_plot(
    "numslengthusername",
    model.predict,
    X100,
    ice=False,
    model_expected_value=True,
    feature_expected_value=True,
)

# In[13]:


shap.partial_dependence_plot(
    "externalURL",
    model.predict,
    X100,
    ice=False,
    model_expected_value=True,
    feature_expected_value=True,
)

# In[14]:


shap.partial_dependence_plot(
    "followers",
    model.predict,
    X100,
    ice=False,
    model_expected_value=True,
    feature_expected_value=True,
)

# In[ ]:
