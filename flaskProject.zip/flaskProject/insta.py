import instaloader
from io import BytesIO
import requests
from PIL import Image
import numpy as np

import fake_account_detection


def find_ratio_of_name(name: str):
    if name == '':
        return 0
    digits = 0
    for i in name:
        if i.isdigit():
            digits += 1
    if float(format(digits / len(name), '.2f')) == 0.0:
        return 0
    else:
        return float(format(digits / len(name), '.2f'))


def find_no_of_words_in_name(name: str):
    return len(name.split(' '))


def name_is_equal_to_username(name: str, uname: str):
    if name.__eq__(uname):
        return 1
    else:
        return 0


def external_url_formatter(external_url: str):
    if external_url.__eq__(None):
        return 0
    else:
        return 1


def download_image(url):
    response = requests.get(url)
    image = Image.open(BytesIO(response.content))
    return image


def get_is_profile_available(image_2):
    try:
        img1 = Image.open("./assets/profile.jpg")
        img2 = download_image(image_2)

        return (not np.array_equal(np.array(img1), np.array(img2))).__abs__()

    except Exception as e:
        print(f"An error occurred: {e}")
        return 0


def get_profile(username):
    insta = instaloader.Instaloader()
    try:
        profile = instaloader.Profile.from_username(insta.context, username=username)
        return [True, profile]
    except Exception as e:
        print(e)
        return [False, "username-not-found"]


def get_user_data(username):
    result = get_profile(username)
    if not result[0]:
        return result
    else:
        profile = result[1]
        data = {
            'profile_pic': profile.profile_pic_url,
            'is_profile_available': get_is_profile_available(profile.profile_pic_url),
            'nums_length_username': find_ratio_of_name(profile.username),
            'username': profile.username,
            'full_name': profile.full_name,
            'full_name_words': find_no_of_words_in_name(profile.full_name),
            'nums_length_full_name': find_ratio_of_name(profile.full_name),
            'name_equals_username': name_is_equal_to_username(profile.username, profile.full_name),
            'description': profile.biography,
            'description_length': len(profile.biography),
            'external_url': external_url_formatter(profile.external_url),
            'private': profile.is_private.__abs__(),
            'posts': profile.mediacount,
            'followers': profile.followers,
            'following': profile.followees,
        }
        return data


def get_data(username):
    result = get_profile(username)
    if not result[0]:
        return result[1]
    else:
        return fake_account_detection.fake_account_detection(get_user_data(username=username))
