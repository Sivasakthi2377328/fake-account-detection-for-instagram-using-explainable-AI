import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.svm import SVC
import pandas as pd
from flask import render_template
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.preprocessing import StandardScaler


def fake_account_detection(input_data):
    input_query = np.array([[
        int(input_data.get('is_profile_available')),
        float(input_data.get('nums_length_username')),
        int(input_data.get('full_name_words')),
        float(input_data.get('nums_length_full_name')),
        int(input_data.get('name_equals_username')),
        int(input_data.get('description_length')),
        int(input_data.get('external_url')),
        int(input_data.get('private')),
        int(input_data.get('posts')),
        int(input_data.get('followers')),
        int(input_data.get('following'))
    ]])

    train_data = pd.read_csv('train.csv')
    x_train = train_data.drop(columns=['fake'])
    y_train = train_data['fake']
    scaler = StandardScaler()
    x_train = scaler.fit_transform(x_train)
    model1 = LogisticRegression()
    model2 = RandomForestClassifier()
    model3 = make_pipeline(StandardScaler(), SVC(probability=True))

    # Creating the voting classifier
    model = VotingClassifier(
        estimators=[('lr', model1), ('rf', model2), ('svm', model3)],
        voting='hard',
        verbose=1
    )

    model.fit(x_train, y_train)
    result = model.predict(scaler.transform(input_query))
    if result == 1:
        return render_template('display.html', result="Fake")
    else:
        return render_template('display.html', result="Real")
